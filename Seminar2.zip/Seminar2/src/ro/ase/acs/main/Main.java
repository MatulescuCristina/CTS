package ro.ase.acs.main;

import ro.ase.acs.readers.ConsoleReader;
import ro.ase.acs.services.Orchestrator;
import ro.ase.acs.writers.ConsoleWriter;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException{
        /*ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new FileWriter();
        writer.write(reader.read());

        try{
            reader.close();
        }catch (IOException e) {
            e.printStackTrace();
        }

         */

        Orchestrator orchestrator =
                new Orchestrator(new ConsoleReader(),
                     new ConsoleWriter());
        orchestrator.execute();
    }
}
