package ro.ase.acs.writers;

public interface Writeable {
    public void write(String message);
}
