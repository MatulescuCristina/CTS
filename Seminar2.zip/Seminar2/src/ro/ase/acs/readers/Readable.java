package ro.ase.acs.readers;

public interface Readable {
    public String read();
}
